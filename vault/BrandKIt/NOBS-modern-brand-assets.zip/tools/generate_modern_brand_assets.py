#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import json
import math
import shutil
import textwrap


ROOT = Path(__file__).resolve().parents[1]
VAULT = Path("/Users/alexburgess/nobs/vault/BrandKIt")
SITE = Path("/Users/alexburgess/nobs/nobs-site")

INK = "#0A0D12"
WHITE = "#F7F9FC"
MUTED = "#A4ACB8"
BLUE = "#3478F6"
GREEN = "#30A46C"
AMBER = "#D98A18"
PANEL = "#171C25"
LINE = "#2E3644"
LIGHT_BG = "#F7F8FB"

FONT_BOLD = "/System/Library/Fonts/Supplemental/Arial Bold.ttf"
FONT_REG = "/System/Library/Fonts/Helvetica.ttc"


def font(size: int, bold: bool = False) -> ImageFont.FreeTypeFont:
    return ImageFont.truetype(FONT_BOLD if bold else FONT_REG, size)


def ensure_dirs(base: Path) -> None:
    for name in ["logo", "wordmark", "lockup", "icon", "banner", "palette", "favicon"]:
        (base / "assets" / name).mkdir(parents=True, exist_ok=True)


def text_size(draw: ImageDraw.ImageDraw, text: str, fnt: ImageFont.FreeTypeFont) -> tuple[int, int]:
    box = draw.textbbox((0, 0), text, font=fnt)
    return box[2] - box[0], box[3] - box[1]


def draw_wordmark(draw: ImageDraw.ImageDraw, xy: tuple[int, int], size: int, color: str, dot: str = GREEN) -> tuple[int, int]:
    x, y = xy
    fnt = font(size, True)
    draw.text((x, y), "NOBS", font=fnt, fill=color)
    tw, th = text_size(draw, "NOBS", fnt)
    r = max(5, int(size * 0.11))
    dot_x = x + tw + int(size * 0.12)
    dot_y = y + int(th * 0.72)
    draw.ellipse((dot_x, dot_y, dot_x + r * 2, dot_y + r * 2), fill=dot)
    return dot_x + r * 2, y + th


def wordmark_image(width: int, height: int, bg: str | None, text: str, dot: str = GREEN) -> Image.Image:
    img = Image.new("RGBA", (width, height), bg or (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    size = int(height * 0.45)
    while size > 10:
        w, _ = text_size(draw, "NOBS", font(size, True))
        if w + int(size * 0.38) < width * 0.84:
            break
        size -= 4
    fnt = font(size, True)
    tw, th = text_size(draw, "NOBS", fnt)
    total = tw + int(size * 0.34)
    x = (width - total) // 2
    y = (height - th) // 2 - int(size * 0.08)
    draw_wordmark(draw, (x, y), size, text, dot)
    return img


def mark_image(size: int, bg: str | None, text: str, dot: str = GREEN) -> Image.Image:
    img = Image.new("RGBA", (size, size), bg or (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    pad = int(size * 0.13)
    if bg:
        draw.rounded_rectangle((0, 0, size - 1, size - 1), radius=int(size * 0.24), fill=bg)
    fnt = font(int(size * 0.48), True)
    tw, th = text_size(draw, "N", fnt)
    draw.text(((size - tw) // 2 - int(size * 0.03), (size - th) // 2 - int(size * 0.05)), "N", font=fnt, fill=text)
    r = int(size * 0.055)
    cx = size - pad - r
    cy = size - pad - r
    draw.ellipse((cx - r, cy - r, cx + r, cy + r), fill=dot)
    return img


def save_png(img: Image.Image, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    img.save(path)


def save_webp(img: Image.Image, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    img.convert("RGB").save(path, quality=95, method=6)


def save_pdf(img: Image.Image, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    img.convert("RGB").save(path, "PDF", resolution=300.0)


def save_svg(path: Path, body: str, width: int, height: int) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        f'<svg width="{width}" height="{height}" viewBox="0 0 {width} {height}" fill="none" xmlns="http://www.w3.org/2000/svg">\n'
        f"{body}\n</svg>\n",
        encoding="utf-8",
    )


def svg_assets(base: Path) -> None:
    save_svg(
        base / "assets/wordmark/nobs-wordmark-modern-light.svg",
        '<text x="48" y="96" fill="#F7F9FC" font-family="-apple-system, BlinkMacSystemFont, Helvetica, Arial, sans-serif" font-size="82" font-weight="800" letter-spacing="0">NOBS</text>\n'
        '<circle cx="296" cy="79" r="9" fill="#30A46C"/>\n'
        '<circle cx="296" cy="79" r="17" stroke="#30A46C" stroke-opacity="0.22" stroke-width="3"/>',
        340,
        128,
    )
    save_svg(
        base / "assets/wordmark/nobs-wordmark-modern-dark.svg",
        '<text x="48" y="96" fill="#0A0D12" font-family="-apple-system, BlinkMacSystemFont, Helvetica, Arial, sans-serif" font-size="82" font-weight="800" letter-spacing="0">NOBS</text>\n'
        '<circle cx="296" cy="79" r="9" fill="#30A46C"/>\n'
        '<circle cx="296" cy="79" r="17" stroke="#30A46C" stroke-opacity="0.18" stroke-width="3"/>',
        340,
        128,
    )
    save_svg(
        base / "assets/logo/nobs-mark-modern.svg",
        '<rect width="128" height="128" rx="31" fill="#0A0D12"/>\n'
        '<text x="39" y="84" fill="#F7F9FC" font-family="-apple-system, BlinkMacSystemFont, Helvetica, Arial, sans-serif" font-size="58" font-weight="800">N</text>\n'
        '<circle cx="92" cy="92" r="7" fill="#30A46C"/>',
        128,
        128,
    )
    save_svg(
        base / "assets/lockup/nobs-lockup-modern-horizontal.svg",
        '<text x="40" y="92" fill="#0A0D12" font-family="-apple-system, BlinkMacSystemFont, Helvetica, Arial, sans-serif" font-size="76" font-weight="800">NOBS</text>\n'
        '<circle cx="270" cy="75" r="8" fill="#30A46C"/>\n'
        '<text x="304" y="78" fill="#66707C" font-family="-apple-system, BlinkMacSystemFont, Helvetica, Arial, sans-serif" font-size="25" font-weight="650">Private family AI</text>',
        560,
        128,
    )


def gradient_bg(size: tuple[int, int]) -> Image.Image:
    width, height = size
    img = Image.new("RGB", (width, height), INK)
    pix = img.load()
    for y in range(height):
        for x in range(width):
            nx = x / width
            ny = y / height
            blue = int(20 + 30 * nx + 16 * math.sin(ny * math.pi))
            green = int(22 + 28 * (1 - nx) * ny)
            red = int(7 + 14 * ny)
            pix[x, y] = (red, green, blue)
    return img.convert("RGBA")


def draw_lines(img: Image.Image) -> None:
    draw = ImageDraw.Draw(img, "RGBA")
    width, height = img.size
    pts = [
        (width * 0.08, height * 0.26),
        (width * 0.28, height * 0.18),
        (width * 0.50, height * 0.34),
        (width * 0.72, height * 0.22),
        (width * 0.90, height * 0.42),
        (width * 0.68, height * 0.72),
        (width * 0.36, height * 0.66),
        (width * 0.14, height * 0.80),
    ]
    for i in range(len(pts) - 1):
        draw.line((pts[i], pts[i + 1]), fill=(52, 120, 246, 46), width=max(2, width // 700))
    for x, y in pts:
        r = max(5, width // 170)
        draw.ellipse((x - r, y - r, x + r, y + r), fill=(52, 120, 246, 210))
        draw.ellipse((x - r * 2.4, y - r * 2.4, x + r * 2.4, y + r * 2.4), outline=(52, 120, 246, 44), width=max(2, width // 900))


def banner(width: int, height: int, title: str, subtitle: str, footer: str, kind: str) -> Image.Image:
    img = gradient_bg((width, height))
    draw = ImageDraw.Draw(img, "RGBA")
    draw_lines(img)
    margin = int(width * 0.07)
    top = int(height * 0.16)
    title_size = max(48, int(min(width, height) * (0.18 if width <= height else 0.16)))
    title_f = font(title_size, True)
    sub_f = font(max(26, int(title_size * 0.24)), False)
    foot_f = font(max(18, int(title_size * 0.15)), True)
    draw_wordmark(draw, (margin, top), title_size, WHITE, GREEN)
    y = top + int(title_size * 1.15)
    for line in textwrap.wrap(subtitle, width=38 if width > height else 20):
        draw.text((margin, y), line, font=sub_f, fill=MUTED)
        y += int(sub_f.size * 1.25)
    pill_w = int(width * (0.34 if width > height else 0.62))
    pill_h = max(48, int(height * 0.075))
    py = height - margin - pill_h
    draw.rounded_rectangle(
        (margin, py, margin + pill_w, py + pill_h),
        radius=pill_h // 2,
        fill=(10, 13, 18, 190),
        outline=(255, 255, 255, 54),
        width=2,
    )
    draw.text((margin + int(pill_h * 0.45), py + int(pill_h * 0.28)), footer, font=foot_f, fill=WHITE)
    return img


def make_palette(base: Path) -> None:
    colors = [
        ("Ink", INK), ("White", WHITE), ("Blue", BLUE), ("Signal", GREEN),
        ("Amber", AMBER), ("Panel", PANEL), ("Line", LINE), ("Light", LIGHT_BG),
    ]
    img = Image.new("RGBA", (1600, 900), LIGHT_BG)
    draw = ImageDraw.Draw(img)
    draw.text((80, 80), "NOBS palette", font=font(82, True), fill=INK)
    draw.text((80, 170), "Simple, modern, friendly, secure.", font=font(34), fill="#66707C")
    x, y = 80, 280
    for i, (name, color) in enumerate(colors):
        cx = x + (i % 4) * 360
        cy = y + (i // 4) * 230
        draw.rounded_rectangle((cx, cy, cx + 280, cy + 120), radius=24, fill=color)
        draw.text((cx, cy + 142), name, font=font(26, True), fill=INK)
        draw.text((cx, cy + 178), color, font=font(22), fill="#66707C")
    save_png(img, base / "assets/palette/nobs-modern-palette.png")


def render_all(base: Path) -> None:
    ensure_dirs(base)
    svg_assets(base)
    sizes = [256, 512, 1024, 2048, 4096]
    for s in sizes:
        save_png(wordmark_image(s * 3, s, None, WHITE), base / f"assets/wordmark/nobs-wordmark-light-{s}.png")
        save_png(wordmark_image(s * 3, s, None, INK), base / f"assets/wordmark/nobs-wordmark-dark-{s}.png")
    for s in [16, 32, 48, 64, 128, 180, 256, 512, 1024, 2048]:
        save_png(mark_image(s, INK, WHITE), base / f"assets/icon/nobs-mark-{s}.png")
        save_png(mark_image(s, None, INK), base / f"assets/logo/nobs-dot-mark-{s}.png")
    ico_imgs = [mark_image(s, INK, WHITE).convert("RGBA") for s in [16, 32, 48, 64, 128, 256]]
    ico_imgs[0].save(base / "assets/favicon/favicon.ico", sizes=[(s, s) for s in [16, 32, 48, 64, 128, 256]])
    save_png(mark_image(180, INK, WHITE), base / "assets/favicon/apple-touch-icon.png")
    save_png(mark_image(512, INK, WHITE), base / "assets/favicon/icon-512.png")
    save_png(wordmark_image(1800, 480, None, INK), base / "assets/logo/nobs-logo-transparent-dark.png")
    save_png(wordmark_image(1800, 480, None, WHITE), base / "assets/logo/nobs-logo-transparent-light.png")
    save_webp(wordmark_image(1800, 480, LIGHT_BG, INK), base / "assets/logo/nobs-logo-dark.webp")
    save_webp(wordmark_image(1800, 480, INK, WHITE), base / "assets/logo/nobs-logo-light.webp")
    save_pdf(wordmark_image(3600, 960, LIGHT_BG, INK), base / "assets/logo/nobs-logo-dark.pdf")
    save_pdf(wordmark_image(3600, 960, INK, WHITE), base / "assets/logo/nobs-logo-light.pdf")
    save_png(wordmark_image(2200, 620, LIGHT_BG, INK), base / "assets/lockup/nobs-lockup-light-2200x620.png")
    save_png(wordmark_image(2200, 620, INK, WHITE), base / "assets/lockup/nobs-lockup-dark-2200x620.png")
    banner_specs = [
        ("nobs-og-card-1200x630.png", 1200, 630, "NOBS", "Private AI for everyday family life.", "LOCAL FIRST", "og"),
        ("nobs-profile-header-1500x500.png", 1500, 500, "NOBS", "Friendly, private, permission-first AI.", "NOBSDASH.COM", "header"),
        ("nobs-linkedin-banner-1584x396.png", 1584, 396, "NOBS", "Apple-native help for phones, homes, and families.", "PRIVATE FAMILY AI", "linkedin"),
        ("nobs-youtube-banner-2560x1440.png", 2560, 1440, "NOBS", "A smarter layer for Apple homes.", "LOCAL · FAMILY · SECURE", "youtube"),
        ("nobs-square-post-1080x1080.png", 1080, 1080, "NOBS", "Private by default. Helpful by permission.", "NO CLOUD DRAG", "square"),
        ("nobs-story-1080x1920.png", 1080, 1920, "NOBS", "Your AI, on your side of the wall.", "ASK BEFORE ACTING", "story"),
        ("nobs-app-store-feature-4320x2160.png", 4320, 2160, "NOBS", "Private family AI for everyday Apple life.", "IPHONE · MAC · HOME", "feature"),
        ("nobs-desktop-wallpaper-3840x2160.png", 3840, 2160, "NOBS", "Friendly. Clean. Secure.", "NOBS", "wallpaper"),
    ]
    for name, w, h, title, sub, footer, kind in banner_specs:
        img = banner(w, h, title, sub, footer, kind)
        save_png(img, base / "assets/banner" / name)
        save_webp(img, base / "assets/banner" / name.replace(".png", ".webp"))
    make_palette(base)
    manifest = {
        "brand": "NOBS",
        "version": "modern-wordmark-2026-06-03",
        "logo": "wordmark plus signal dot",
        "colors": {"ink": INK, "white": WHITE, "blue": BLUE, "signal": GREEN, "amber": AMBER},
        "generated_assets": sorted(str(p.relative_to(base)) for p in (base / "assets").rglob("*") if p.is_file()),
    }
    (base / "assets/manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")


def mirror_to_vault() -> None:
    ensure_dirs(VAULT)
    src = ROOT / "assets"
    dst = VAULT / "assets"
    if dst.exists():
        shutil.rmtree(dst)
    shutil.copytree(src, dst)


def mirror_to_site() -> None:
    site_assets = SITE / "assets"
    site_assets.mkdir(parents=True, exist_ok=True)
    shutil.copy2(ROOT / "assets/wordmark/nobs-wordmark-modern-light.svg", site_assets / "nobs-logo.svg")
    shutil.copy2(ROOT / "assets/banner/nobs-og-card-1200x630.png", site_assets / "nobs-og-card.png")
    shutil.copy2(ROOT / "assets/favicon/favicon.ico", site_assets / "favicon.ico")
    shutil.copy2(ROOT / "assets/favicon/apple-touch-icon.png", site_assets / "apple-touch-icon.png")


if __name__ == "__main__":
    render_all(ROOT)
    mirror_to_vault()
    mirror_to_site()
    print(f"Generated brand assets in {ROOT / 'assets'}")
    print(f"Mirrored assets into {VAULT / 'assets'}")
    print(f"Updated site assets in {SITE / 'assets'}")
